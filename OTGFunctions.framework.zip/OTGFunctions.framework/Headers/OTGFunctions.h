//
//  OTGFunctions.h
//  OTGFunctions
//
//  Created by Raghul S on 14/04/24.
//

#import <Foundation/Foundation.h>

//! Project version number for OTGFunctions.
FOUNDATION_EXPORT double OTGFunctionsVersionNumber;

//! Project version string for OTGFunctions.
FOUNDATION_EXPORT const unsigned char OTGFunctionsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OTGFunctions/PublicHeader.h>


